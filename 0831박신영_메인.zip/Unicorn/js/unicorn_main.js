window.onload = function() {
    openBanner('mainBanner')
}

function openBanner(target) {
    document.getElementById(target).style.display = 'block';
    let mainBanner = document.getElementById('mainBanner');

   let notice = document.getElementById('notice');
   let classroom = document.getElementById('classroom');
   let hotPlace = document.getElementById('hotPlace');
   let reservation = document.getElementById('reservation');
   

    if(target == "notice") {
        notice.style.backgroundColor = 'pink';
        document.getElementById('notic_button').style.backgroundColor = 'pink';
        notice.style.display = 'block';
        classroom.style.display = 'none';
        hotPlace.style.display = 'none';
        reservation.style.display = 'none';
        mainBanner.style.display = 'none';
        

    } else if (target == "classroom") {
        classroom.style.backgroundColor = 'yellow';
        notice.style.display = 'none';
        classroom.style.display = 'block';
        hotPlace.style.display = 'none';
        reservation.style.display = 'none';
        mainBanner.style.display = 'none';

    } else if ( target == "hotPlace") {
        hotPlace.style.backgroundColor = 'red';
        notice.style.display = 'none';
        classroom.style.display = 'none';
        hotPlace.style.display = 'block';
        reservation.style.display = 'none';
        mainBanner.style.display = 'none';

    } else if ( target == "reservation") {
        reservation.style.backgroundColor = 'black';
        notice.style.display = 'none';
        classroom.style.display = 'none';
        hotPlace.style.display = 'none';
        reservation.style.display = 'block';
        mainBanner.style.display = 'none';
    }
}

