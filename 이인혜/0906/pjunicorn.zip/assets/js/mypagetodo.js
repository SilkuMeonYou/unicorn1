let title_btn = document.querySelector("#title_btn");

                title_btn.addEventListener("click", function () {
                    console.log("click 실행")

                    let text = document.querySelector("#text");
                    let value = text.value;

                    let view = document.querySelector("#view");
                    let view2 = document.createElement("div");

                    let del = "<input type='button' id='del' value='X'>"
                    let check = "<input type='checkbox' id='check'>"

                    view2.innerHTML = check + " " + value + " " + del;

                    view.prepend(view2);

                    let view3 = document.querySelectorAll("#del");
                    console.log(view3)

                    for (let i = 0; i < view3.length; i++) {
                        view3[i].addEventListener("click", function () {
                            console.log("x실행")

                            if (view3 != null) {
                                view3[i].parentNode.remove();
                                console.log("remove");
                            }
                        })
                    }

                })

                let info = document.querySelector("#tab_info");
                info.addEventListener("click",function() {

                    info.style.backgroundColor = "rgba(255, 255, 255, 0.301)";
                    calendar.style.backgroundColor = "rgb(34, 50, 65)";
                    like.style.backgroundColor = "rgb(34, 50, 65)";
                    todo.style.backgroundColor = "rgb(34, 50, 65)";
                })
                
                let calendar = document.querySelector("#tab_calendar");
                calendar.addEventListener("click",function() {

                    info.style.backgroundColor = "rgb(34, 50, 65)";
                    calendar.style.backgroundColor = "rgba(255, 255, 255, 0.301)";
                    like.style.backgroundColor = "rgb(34, 50, 65)";
                    todo.style.backgroundColor = "rgb(34, 50, 65)";
                })
                
                let like = document.querySelector("#tab_like");
                like.addEventListener("click",function() {
                    
                    info.style.backgroundColor = "rgb(34, 50, 65)";
                    calendar.style.backgroundColor = "rgb(34, 50, 65)";
                    like.style.backgroundColor = "rgba(255, 255, 255, 0.301)";
                    todo.style.backgroundColor = "rgb(34, 50, 65)";
                })

                 let todo = document.querySelector("#tab_todo");
                todo.addEventListener("click",function() {

                    info.style.backgroundColor = "rgb(34, 50, 65)";
                    calendar.style.backgroundColor = "rgb(34, 50, 65)";
                    like.style.backgroundColor = "rgb(34, 50, 65)";
                    todo.style.backgroundColor = "rgba(255, 255, 255, 0.301)";
                })